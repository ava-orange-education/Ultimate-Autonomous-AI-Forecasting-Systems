"""
01_timegpt_basic.py
TimeGPT setup and basic usage (Nixtla TimeGPT).

Notes:
- Replace `your_api_token` with your real token.
- Replace `your_dates` and `your_values` with your data.
- Ensure `ds` is datetime-like.
"""

import pandas as pd
from nixtla import TimeGPT

# Initialize TimeGPT client
timegpt = TimeGPT(token="your_api_token")

# Example placeholders (replace with real data)
your_dates = pd.date_range("2025-01-01", periods=30, freq="D")
your_values = list(range(100, 130))

df = pd.DataFrame({
    "unique_id": ["series_1"] * len(your_values),
    "ds": your_dates,
    "y": your_values,
})

forecast_df = timegpt.forecast(
    df=df,
    h=24,
    level=[80, 95],
    freq="D"
)

print(forecast_df)
