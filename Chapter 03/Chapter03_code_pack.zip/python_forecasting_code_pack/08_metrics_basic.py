"""
08_metrics_basic.py
Traditional metrics implementation: MAE, RMSE, MAPE, sMAPE.
"""

import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error

def calculate_basic_metrics(y_true, y_pred):
    metrics = {}
    metrics["mae"] = mean_absolute_error(y_true, y_pred)
    metrics["rmse"] = np.sqrt(mean_squared_error(y_true, y_pred))
    metrics["mape"] = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    metrics["smape"] = (
        np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred))) * 100
    )
    return metrics
