"""
13_arima_example.py
Traditional ARIMA approach using statsmodels.

Notes:
- Requires manual selection of (p, d, q).
- `data_series` should be a 1D array-like or pandas Series.
"""

from statsmodels.tsa.arima.model import ARIMA
import pandas as pd

# Example placeholder data
data_series = pd.Series(range(100, 160))

# Manual ARIMA order (placeholder)
p, d, q = 1, 1, 1
horizon = 5

model = ARIMA(data_series, order=(p, d, q))
fitted_model = model.fit()

forecast = fitted_model.forecast(steps=horizon)
print(forecast)

# Confidence intervals (optional)
forecast_result = fitted_model.get_forecast(steps=horizon)
print("Predicted Mean:")
print(forecast_result.predicted_mean)
print("\nConfidence Interval:")
print(forecast_result.conf_int())
