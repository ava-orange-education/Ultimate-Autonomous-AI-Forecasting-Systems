"""
12_transformer_timeseries_conceptual.py
Conceptual Transformer adaptation for time series forecasting (PyTorch).

This file defines the shell; you must implement:
- TemporalPositionalEncoding
- TemporalAttention
- ForecastingHead
"""

import torch
import torch.nn as nn

class TemporalPositionalEncoding(nn.Module):
    def __init__(self, d_model):
        super().__init__()
        self.d_model = d_model

    def forward(self, x):
        return x

class TemporalAttention(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads

    def forward(self, x):
        return x

class ForecastingHead(nn.Module):
    def __init__(self, d_model, out_dim=1):
        super().__init__()
        self.proj = nn.Linear(d_model, out_dim)

    def forward(self, x):
        # Example: predict next-step for each time point -> (B, T, out_dim)
        return self.proj(x)

class TimeSeriesTransformer(nn.Module):
    def __init__(self, d_model, n_heads, n_layers):
        super(TimeSeriesTransformer, self).__init__()
        self.temporal_encoding = TemporalPositionalEncoding(d_model)
        self.attention_layers = nn.ModuleList([
            TemporalAttention(d_model, n_heads) for _ in range(n_layers)
        ])
        self.forecast_head = ForecastingHead(d_model)

    def forward(self, x):
        x = self.temporal_encoding(x)
        for attn in self.attention_layers:
            x = attn(x)
        forecast = self.forecast_head(x)
        return forecast
