"""
03_retail_new_product_forecast.py
Retail demand forecasting example: new product launch + cross-product learning.

Notes:
- `identify_similar_products` is a stub; implement your own similarity logic.
- `combined_data` should contain series for similar products (multi-series support).
"""

import pandas as pd
from nixtla import TimeGPT

timegpt = TimeGPT(token="your_api_token")

def identify_similar_products(new_product):
    # TODO: implement similarity based on attributes, embeddings, or sales patterns.
    return ["prod_A", "prod_B", "prod_C"]

# --- placeholders ---
limited_sales_data = pd.DataFrame({
    "unique_id": ["new_product"] * 28,  # only few weeks
    "ds": pd.date_range("2025-01-01", periods=28, freq="D"),
    "y": ([50, 55, 53, 60, 58, 62, 65] * 4)
})

product_attributes = pd.DataFrame({
    "unique_id": ["new_product"] * 52,
    "ds": pd.date_range("2025-01-29", periods=52, freq="W"),
    "category": ["sweater"] * 52,
    "price": [999.0] * 52,
    "feature_score": [0.8] * 52,
})

new_product_forecast = timegpt.forecast(
    df=limited_sales_data,
    h=52,                 # forecast full year (weekly)
    X_df=product_attributes,
    level=[80, 95]
)

print(new_product_forecast)

new_product = {"id": "new_product", "category": "sweater"}
similar_products = identify_similar_products(new_product)

# Example combined dataset (multi-series)
combined_data = pd.concat([
    limited_sales_data.assign(unique_id="prod_A"),
    limited_sales_data.assign(unique_id="prod_B"),
    limited_sales_data.assign(unique_id="prod_C"),
])

enhanced_forecast = timegpt.forecast(
    df=combined_data,
    h=26,
    add_history=True
)

print(enhanced_forecast)
