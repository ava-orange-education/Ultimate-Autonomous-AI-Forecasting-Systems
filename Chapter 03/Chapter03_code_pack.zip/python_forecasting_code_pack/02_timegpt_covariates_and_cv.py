"""
02_timegpt_covariates_and_cv.py
Advanced TimeGPT usage with exogenous variables + cross-validation.

Notes:
- `X_df` should include future values for covariates aligned with forecast horizon.
- Exact column requirements depend on your Nixtla version / settings.
"""

import pandas as pd
from nixtla import TimeGPT

timegpt = TimeGPT(token="your_api_token")

# --- placeholders ---
df = pd.DataFrame({
    "unique_id": ["series_1"] * 90,
    "ds": pd.date_range("2025-01-01", periods=90, freq="D"),
    "y": list(range(100, 190)),
})

# Example covariates for future horizon (h=24)
df_with_covariates = df.copy()
exogenous_variables = pd.DataFrame({
    "unique_id": ["series_1"] * 24,
    "ds": pd.date_range(df["ds"].iloc[-1] + pd.Timedelta(days=1), periods=24, freq="D"),
    "price": [10.0] * 24,
    "promotion": [0] * 24,
})

forecast_with_covariates = timegpt.forecast(
    df=df_with_covariates,
    X_df=exogenous_variables,
    h=24,
    level=[90],
    add_history=True,
    date_features=True
)

print(forecast_with_covariates)

cv_results = timegpt.cross_validation(
    df=df,
    h=24,
    n_windows=5,
    step_size=24
)

print(cv_results)
