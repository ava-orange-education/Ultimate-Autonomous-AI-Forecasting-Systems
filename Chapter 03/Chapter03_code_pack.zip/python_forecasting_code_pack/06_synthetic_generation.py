"""
06_synthetic_generation.py
Synthetic time series generation example (conceptual).
"""

def generate_synthetic_series(base_series, model, conditions):
    """
    Generate synthetic time series variants using a generative model.

    base_series : original time series data
    model       : generative time series model with .generate(...)
    conditions  : constraints like volatility, trend, seasonality
    """
    synthetic_series = model.generate(
        seed_data=base_series[-100:],   # use recent history as seed
        length=365,                     # generate one year of data
        conditions=conditions,          # desired characteristics
        num_samples=10                  # number of synthetic variants
    )
    return synthetic_series


# Example usage (requires your model implementation)
# low_vol_series = generate_synthetic_series(base_series, model, {"volatility": "low"})
# high_vol_series = generate_synthetic_series(base_series, model, {"volatility": "high"})
