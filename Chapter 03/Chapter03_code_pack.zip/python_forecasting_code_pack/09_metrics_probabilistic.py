"""
09_metrics_probabilistic.py
Probabilistic evaluation metrics (conceptual).

Requires you to implement:
- quantile_loss(y_true, y_pred, tau)
- interval_score(y_true, lower, upper, alpha)
"""

import numpy as np

def evaluate_probabilistic_forecast(y_true, forecast_quantiles):
    results = {}

    # Quantile loss calculation
    for q, predictions in forecast_quantiles.items():
        tau = q / 100.0
        results[f"ql_{q}"] = quantile_loss(y_true, predictions, tau)

    # Coverage metrics (90% interval)
    lower_bound = forecast_quantiles[5]
    upper_bound = forecast_quantiles[95]
    coverage = np.mean((y_true >= lower_bound) & (y_true <= upper_bound))
    results["coverage_90"] = coverage

    # Interval score
    results["interval_score"] = interval_score(
        y_true, lower_bound, upper_bound, alpha=0.1
    )

    return results
