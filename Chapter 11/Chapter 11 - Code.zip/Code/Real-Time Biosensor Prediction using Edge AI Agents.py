import streamlit as st
import pandas as pd
import numpy as np
import time

st.set_page_config(
    page_title="Edge AI Biosensor Prediction",
    layout="wide"
)

st.title("Real-Time Biosensor Prediction using Edge AI Agents")

st.markdown("""
This demo simulates an edge-deployed AI agent that reads biosensor values,
predicts short-term health risk, detects anomalies, and generates alerts.
""")

# -----------------------------
# Sidebar Inputs
# -----------------------------
st.sidebar.header("Patient Biosensor Inputs")

glucose = st.sidebar.slider("Glucose Level (mg/dL)", 60, 300, 110)
heart_rate = st.sidebar.slider("Heart Rate (bpm)", 40, 180, 78)
systolic_bp = st.sidebar.slider("Systolic BP", 80, 220, 120)
diastolic_bp = st.sidebar.slider("Diastolic BP", 50, 140, 80)
spo2 = st.sidebar.slider("SpO₂ Level (%)", 70, 100, 98)
ecg_variation = st.sidebar.slider("ECG Variation", 0, 100, 20)

# -----------------------------
# Edge AI Agent Logic
# -----------------------------
def calculate_risk(glucose, heart_rate, systolic_bp, diastolic_bp, spo2, ecg_variation):
    risk_score = 0
    if glucose < 70 or glucose > 180:
        risk_score += 25
    if heart_rate < 50 or heart_rate > 120:
        risk_score += 20
    if systolic_bp > 140 or diastolic_bp > 90:
        risk_score += 20
    if spo2 < 92:
        risk_score += 25
    if ecg_variation > 60:
        risk_score += 20
    return min(risk_score, 100)

risk_score = calculate_risk(
    glucose,     heart_rate,    systolic_bp,    diastolic_bp,    spo2,    ecg_variation
)

# -----------------------------
# Risk Classification
# -----------------------------
if risk_score < 30:
    status = "Normal"
    alert = "No immediate risk detected."
elif risk_score < 60:
    status = "Moderate Risk"
    alert = "Patient needs monitoring."
else:
    status = "High Risk"
    alert = "Immediate medical attention recommended."

# -----------------------------
# Simulated Future Prediction
# -----------------------------
future_glucose = glucose + np.random.randint(-10, 15)
future_hr = heart_rate + np.random.randint(-8, 10)
future_spo2 = spo2 + np.random.randint(-3, 2)
# -----------------------------
# Dashboard
# -----------------------------
col1, col2, col3 = st.columns(3)

col1.metric("Current Glucose", f"{glucose} mg/dL", f"Predicted: {future_glucose}")
col2.metric("Current Heart Rate", f"{heart_rate} bpm", f"Predicted: {future_hr}")
col3.metric("Current SpO₂", f"{spo2}%", f"Predicted: {future_spo2}%")

col4, col5, col6 = st.columns(3)

col4.metric("Blood Pressure", f"{systolic_bp}/{diastolic_bp}")
col5.metric("ECG Variation", ecg_variation)
col6.metric("Risk Score", f"{risk_score}%")

st.subheader("Edge AI Agent Prediction Result")

if status == "Normal":
    st.success(f"Status: {status}")
elif status == "Moderate Risk":
    st.warning(f"Status: {status}")
else:
    st.error(f"Status: {status}")

st.info(alert)
# -----------------------------
# Data Table
# -----------------------------
data = pd.DataFrame({
    "Biosensor": [  "Glucose",  "Heart Rate", "Systolic BP", "Diastolic BP",  "SpO₂",    "ECG Variation"
    ],
    "Current Value": [  glucose, heart_rate, systolic_bp, diastolic_bp, spo2, ecg_variation ],
    "Normal Range": ["70 - 140 mg/dL", "60 - 100 bpm",  "90 - 120", "60 - 80", "95 - 100%", "0 - 40"  ]})

st.subheader("Biosensor Reading Summary")
st.dataframe(data, use_container_width=True)

# -----------------------------
# Simulated Trend Chart
# -----------------------------
st.subheader("Real-Time Biosensor Trend Simulation")

time_points = list(range(1, 11))

trend_data = pd.DataFrame({
    "Time": time_points,
    "Glucose": glucose + np.random.randint(-15, 15, 10),
    "Heart Rate": heart_rate + np.random.randint(-10, 10, 10),
    "SpO₂": spo2 + np.random.randint(-3, 3, 10)
})

st.line_chart(trend_data.set_index("Time"))

# -----------------------------
# Decision Support
# -----------------------------
st.subheader("Decision Support Recommendation")

if risk_score < 30:
    st.write("Patient condition appears stable. Continue routine monitoring.")
elif risk_score < 60:
    st.write("Patient shows moderate risk. Increase monitoring frequency and review recent readings.")
else:
    st.write("High-risk condition detected. Notify healthcare provider immediately and prepare clinical intervention.")
st.caption("Note: This is a demo application for educational purposes only."
