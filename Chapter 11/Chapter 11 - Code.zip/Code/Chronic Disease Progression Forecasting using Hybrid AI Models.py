import streamlit as st
import pandas as pd

st.set_page_config(page_title="Disease Progression Predictor")
st.title("🏥 Chronic Disease Progression Modeling")
st.subheader("Patient Information")

age = st.number_input("Age", 20, 100, 45)
bp = st.number_input("Blood Pressure", 80, 220, 120)
sugar = st.number_input("Blood Sugar", 50, 400, 120)
cholesterol = st.number_input("Cholesterol", 100, 500, 180)
bmi = st.number_input("BMI", 10.0, 50.0, 24.5)
heart_rate = st.number_input("Heart Rate", 40, 180, 75)
duration = st.number_input("Disease Duration (Years)", 0, 30, 2)

if st.button("Predict Progression"):

    risk_score = ( age * 0.1 +  bp * 0.15 + sugar * 0.25 + cholesterol * 0.15 +   bmi * 0.15 +
        duration * 2    )

    if risk_score < 80:
        status = "Stable"
        recommendation = "Continue current treatment and routine monitoring."
    elif risk_score < 120:
        status = "Moderate Risk"
        recommendation = "Increase monitoring and review treatment plan."
    else:
        status = "High Risk"
        recommendation = "Immediate clinical attention recommended."

    st.subheader("Prediction Result")
    st.metric("Risk Score", round(risk_score,2))
    st.success(status)
    st.info(recommendation)

    result = pd.DataFrame({
        "Parameter":[    "Age", "Blood Pressure", "Blood Sugar", "Cholesterol",
            "BMI", "Disease Duration" ],
        "Value":[ age, bp, sugar, cholesterol, bmi, duration] })

    st.dataframe(result)
