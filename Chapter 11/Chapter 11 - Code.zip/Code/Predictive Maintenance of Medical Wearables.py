import streamlit as st
import pandas as pd

st.set_page_config(page_title="Medical Device Predictive Maintenance", layout="wide")

st.title("Medical Device Predictive Maintenance using Agentic AI")

st.write(
    "This demo predicts medical device health, detects anomalies, "
    "estimates remaining useful life, and recommends maintenance actions."
)

# Sidebar inputs
st.sidebar.header("Device Input Data")

device_type = st.sidebar.selectbox(
    "Device Type",
    ["Pacemaker", "Glucose Sensor", "Insulin Pump", "ECG Monitor", "Wearable Monitor"]
)

battery_level = st.sidebar.slider("Battery Level (%)", 0, 100, 80)
signal_quality = st.sidebar.slider("Signal Quality (%)", 0, 100, 85)
device_temperature = st.sidebar.slider("Device Temperature (°C)", 20, 60, 36)
sensor_accuracy = st.sidebar.slider("Sensor Accuracy (%)", 0, 100, 90)
communication_stability = st.sidebar.slider("Communication Stability (%)", 0, 100, 88)
usage_days = st.sidebar.slider("Device Usage Duration (Days)", 1, 1000, 120)

# Agentic health scoring logic
def calculate_health_score(
    battery, signal, temp, accuracy, communication, usage
):
    score = 100

    if battery < 30:
        score -= 25
    elif battery < 50:
        score -= 10

    if signal < 60:
        score -= 20
    elif signal < 80:
        score -= 10

    if temp > 45:
        score -= 20
    elif temp > 40:
        score -= 10

    if accuracy < 70:
        score -= 20
    elif accuracy < 85:
        score -= 10

    if communication < 70:
        score -= 15
    elif communication < 85:
        score -= 8

    if usage > 700:
        score -= 15
    elif usage > 400:
        score -= 8

    return max(score, 0)

health_score = calculate_health_score(
    battery_level,
    signal_quality,
    device_temperature,
    sensor_accuracy,
    communication_stability,
    usage_days
)

# Remaining useful life estimation
remaining_days = int((health_score / 100) * 60)

# Risk classification
if health_score >= 75:
    status = "Healthy"
    alert_type = "No critical issue detected."
    recommendation = "Continue normal monitoring."
elif health_score >= 50:
    status = "Warning"
    alert_type = "Device performance is degrading."
    recommendation = "Schedule inspection and monitor closely."
else:
    status = "Critical"
    alert_type = "High risk of device failure."
    recommendation = "Immediate maintenance or replacement recommended."

# Dashboard
col1, col2, col3, col4 = st.columns(4)

col1.metric("Device Type", device_type)
col2.metric("Health Score", f"{health_score}/100")
col3.metric("Remaining Useful Life", f"{remaining_days} days")
col4.metric("Status", status)

st.subheader("Agentic Monitoring Result")

if status == "Healthy":
    st.success(alert_type)
elif status == "Warning":
    st.warning(alert_type)
else:
    st.error(alert_type)

st.info(recommendation)

# Detailed table
device_data = pd.DataFrame({
    "Parameter": [
        "Battery Level",
        "Signal Quality",
        "Device Temperature",
        "Sensor Accuracy",
        "Communication Stability",
        "Usage Duration"
    ],
    "Value": [
        f"{battery_level}%",
        f"{signal_quality}%",
        f"{device_temperature} °C",
        f"{sensor_accuracy}%",
        f"{communication_stability}%",
        f"{usage_days} days"
    ],
    "Agent Observation": [
        "Battery condition checked",
        "Signal transmission quality checked",
        "Temperature stability checked",
        "Sensor performance checked",
        "Connectivity checked",
        "Device ageing checked"
    ]
})

st.subheader("Device Health Analysis")
st.dataframe(device_data, use_container_width=True)

# Maintenance decision
st.subheader("Maintenance Recommendation")

if health_score >= 75:
    st.write("The device is operating normally. No immediate maintenance is required.")
elif health_score >= 50:
    st.write("The device shows early signs of degradation. Preventive maintenance is recommended.")
else:
    st.write("The device is at high risk of failure. Immediate replacement or servicing is required.")

# Simple trend simulation
st.subheader("Device Health Trend")

trend = pd.DataFrame({
    "Day": list(range(1, 8)),
    "Health Score": [
        min(100, health_score + 10),
        min(100, health_score + 7),
        min(100, health_score + 5),
        health_score,
        max(0, health_score - 4),
        max(0, health_score - 8),
        max(0, health_score - 12)
    ]
})

st.line_chart(trend.set_index("Day"))

st.caption("Demo purpose only. Not intended for real clinical diagnosis or medical decision-making.")