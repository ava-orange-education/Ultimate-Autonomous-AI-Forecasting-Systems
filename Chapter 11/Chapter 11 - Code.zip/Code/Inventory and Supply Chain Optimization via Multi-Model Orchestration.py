import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_error
from sklearn.linear_model import LinearRegression
from statsmodels.tsa.arima.model import ARIMA

# -----------------------------
# 1. Sample Sales Data
# -----------------------------
data = {
    "date": pd.date_range(start="2025-01-01", periods=60, freq="D"),
    "sales": [120,125,130,128,135,140,138,145,150,148,
              155,160,158,165,170,168,175,180,178,185,
              190,188,195,200,198,205,210,208,215,220,
              218,225,230,228,235,240,238,245,250,248,
              255,260,258,265,270,268,275,280,278,285,
              290,288,295,300,298,305,310,308,315,320]
}

df = pd.DataFrame(data)

# -----------------------------
# 2. Train-Test Split
# -----------------------------
train = df.iloc[:50]
test = df.iloc[50:]

# -----------------------------
# 3. Model 1: Moving Average
# -----------------------------
moving_avg_forecast = [train["sales"].rolling(7).mean().iloc[-1]] * len(test)

# -----------------------------
# 4. Model 2: Linear Regression
# -----------------------------
train["day"] = np.arange(len(train))
test["day"] = np.arange(len(train), len(train) + len(test))

lr = LinearRegression()
lr.fit(train[["day"]], train["sales"])
lr_forecast = lr.predict(test[["day"]])

# -----------------------------
# 5. Model 3: ARIMA
# -----------------------------
arima_model = ARIMA(train["sales"], order=(2, 1, 2))
arima_fit = arima_model.fit()
arima_forecast = arima_fit.forecast(steps=len(test))

# -----------------------------
# 6. Compare Model Accuracy
# -----------------------------
results = {
    "Moving Average": mean_absolute_error(test["sales"], moving_avg_forecast),
    "Linear Regression": mean_absolute_error(test["sales"], lr_forecast),
    "ARIMA": mean_absolute_error(test["sales"], arima_forecast)
}

best_model = min(results, key=results.get)

print("Model Accuracy Comparison:")
for model, error in results.items():
    print(model, "MAE:", round(error, 2))

print("\nBest Selected Model:", best_model)

# -----------------------------
# 7. Select Forecast from Best Model
# -----------------------------
if best_model == "Moving Average":
    final_forecast = moving_avg_forecast
elif best_model == "Linear Regression":
    final_forecast = lr_forecast
else:
    final_forecast = arima_forecast

future_demand = int(np.mean(final_forecast))

# -----------------------------
# 8. Inventory Optimization Logic
# -----------------------------
current_inventory = 500
lead_time_days = 5
daily_demand = future_demand
safety_stock = int(daily_demand * 0.25)

reorder_point = (daily_demand * lead_time_days) + safety_stock

if current_inventory <= reorder_point:
    decision = "Reorder Required"
    reorder_quantity = reorder_point - current_inventory + 300
else:
    decision = "No Reorder Needed"
    reorder_quantity = 0

# -----------------------------
# 9. Final Output
# -----------------------------
print("\nInventory Optimization Result")
print("Predicted Daily Demand:", daily_demand)
print("Current Inventory:", current_inventory)
print("Safety Stock:", safety_stock)
print("Reorder Point:", reorder_point)
print("Decision:", decision)
print("Recommended Reorder Quantity:", reorder_quantity)